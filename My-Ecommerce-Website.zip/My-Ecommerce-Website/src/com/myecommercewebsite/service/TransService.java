package com.myecommercewebsite.service;

public interface TransService {
	
	public String getUserId(String transId);
}
